//
//  LampViewController.swift
//  SignifyLightControl
//
//  Created by issd on 06/12/2018.
//  Copyright © 2018 issd. All rights reserved.
//

import UIKit

class LampViewController: UIViewController {
 
    @IBOutlet weak var addLamps: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        addLamps.layer.borderWidth = 3;
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onGoButton(_ sender: Any) {
        performSegue( withIdentifier: "pushLamp", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
